package com.example.cartview;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    EditText FullName, Email, Password;
    Button Register;

    RequestQueue requestQueue;
    String NameHolder, EmailHolder, PasswordHolder;

    ProgressDialog progressDialog;

    String HttpUrl = "http://10.0.2.2:80/Volley/User-Registration.php";
    //String HttpUrl = "http://127.0.0.1:80/Volley/User-Registration.php";

    Boolean CheckEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FullName = (EditText) findViewById(R.id.EditTextFullName);
        Email = (EditText) findViewById(R.id.EditTextEmail);
        Password = (EditText) findViewById(R.id.EditTextPassword);
        Register= (Button) findViewById(R.id.ButtonRegister);

        requestQueue = Volley.newRequestQueue(MainActivity.this);
        progressDialog = new ProgressDialog(MainActivity.this);

        Register.setOnClickListener(view -> {
            CheckEditTextIsEmptyOrNot();
            if (CheckEditText) {
                UserRegistration();
            } else {
                Toast.makeText(MainActivity.this, "Please fill all form fields", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void UserRegistration(){
        progressDialog.setMessage("Please Wait, We are inserting Your Data on Server");
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, HttpUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String ServerResponse) {
                        progressDialog.dismiss();
                        Toast.makeText(MainActivity.this, ServerResponse, Toast.LENGTH_LONG).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {
                        progressDialog.dismiss();
                        Toast.makeText(MainActivity.this, volleyError.toString(), Toast.LENGTH_LONG).show();
                        showMessage("Error en Volley", volleyError.toString());
                    }
                })
        {
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params = new HashMap<>();

                params.put("User_Email", EmailHolder);
                params.put("User_Password", PasswordHolder);
                params.put("User_Full_Name", NameHolder);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);

        requestQueue.add(stringRequest);
    }

    public void CheckEditTextIsEmptyOrNot(){
        NameHolder = FullName.getText().toString().trim();
        EmailHolder = Email.getText().toString().trim();
        PasswordHolder= Password.getText().toString().trim();

        if(TextUtils.isEmpty(NameHolder)||TextUtils.isEmpty(EmailHolder) | TextUtils.isEmpty(PasswordHolder)){
            CheckEditText = false;
        }
        else{
            CheckEditText = true;
        }
    }
    public void showMessage(String titulo, String mensaje){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(titulo);
        builder.setMessage(mensaje);
        builder.show();
    }
}